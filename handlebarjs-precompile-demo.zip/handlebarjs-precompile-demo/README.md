# handlebarjs-precompile-demo
handlerbajs demo with grunt plugin
